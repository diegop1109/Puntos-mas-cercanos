/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Package;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author rodri
 */
public class prueba {

    static Algoritmos alg = new Algoritmos();

    public static void main(String[] args) {
        ArrayList<Punto> puntos = new ArrayList<>();
        double start;
        double tiempoQ;
        double tiempoE;
        double tiempoDV;
        Random random = new Random();

        for (int i = 0; i < 1000; i++) {
            int x = random.nextInt(1000);
            int y = random.nextInt(1000);
            puntos.add(new Punto(x, y, i));
        }
        start = System.currentTimeMillis();
        alg.Exhaustivo(puntos);
        tiempoE = System.currentTimeMillis() - start;
        System.out.println("Tiempo Exhaustivo " + tiempoE);

        start = System.currentTimeMillis();
        ArrayList puntosO = alg.QuickSort(puntos);
        tiempoQ = System.currentTimeMillis() - start;
        System.out.println("Tiempo Quick " + tiempoQ);

        start = System.currentTimeMillis();
        alg.DyV(puntosO);
        tiempoDV = System.currentTimeMillis() - start;
        System.out.println("Tiempo Divide " + tiempoDV);
    }
}
