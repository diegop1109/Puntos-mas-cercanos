/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Package;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.math.plot.Plot2DPanel;

/**
 *
 * @author rodri
 */
public class Tabla2 extends javax.swing.JFrame {

    DefaultTableModel model = new DefaultTableModel();
    private ArrayList<Punto> puntos;
    Algoritmos alg = new Algoritmos();
    String text;
    Grafica2 g2;

    /**
     * Creates new form Tabla2
     */
    public Tabla2(String estrategia) {
        initComponents();

        this.g2 = new Grafica2();

        ArrayList tallas = Tallas(5000);
        ArrayList<Double> tiempos = new ArrayList<>();
        ArrayList<Double> tiempos2 = new ArrayList<>();
        String[] titulos = new String[]{"Tallas", "Tiempos"};
        String[] titulos2 = new String[]{"Tallas", "Tiempo", "Tiempo", "Distancias", "Distancias"};
        JFrame j = new JFrame();
        text = estrategia;
        g2.setTitle("Gráfica");
        Plot2DPanel plot = new Plot2DPanel();
        switch (estrategia) {
            case "Exhaustivo":
                model.setColumnIdentifiers(titulos);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.Exhaustivo(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgE()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgE());
                }
                generarDat(tallas, estrategia, tiempos);
                g2.setAlgo("Exhaustivo");
                g2.add(g2.paint(plot, tallas, tiempos));
                break;
            case "ExhaustivoPoda":
                model.setColumnIdentifiers(titulos);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.Exhaustivo_Poda(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgEP()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgEP());
                }
                generarDat(tallas, estrategia, tiempos);
                g2.setAlgo("ExhaustivoPoda");
                g2.add(g2.paint(plot, tallas, tiempos));
                break;
            case "Divide y Vencerás":
                model.setColumnIdentifiers(titulos);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.DyV(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgDV()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgDV());
                }
                generarDat(tallas, estrategia, tiempos);
                g2.setAlgo("Divide y Vencerás");
                g2.add(g2.paint(plot, tallas, tiempos));
                break;
            case "DyV Mejorado":
                model.setColumnIdentifiers(titulos);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.DyV_Mejorado(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgDVM()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgDVM());
                }
                generarDat(tallas, estrategia, tiempos);
                g2.setAlgo("DyV Mejorado");
                g2.add(g2.paint(plot, tallas, tiempos));
                break;
            case "Exhaustivo y Exhaustivo":
                break;
            case "Exhaustivo y ExhaustivoPoda":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.Exhaustivo(puntos);
                    alg.Exhaustivo_Poda(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgE(), alg.getTiempoalgEP(), alg.getContE(), alg.getContEP()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgE());
                    tiempos2.add(alg.getTiempoalgEP());
                }
                generarDat(tallas, "Exhaustivo", tiempos);
                generarDat(tallas, "ExhaustivoPoda", tiempos2);
                g2.setAlgo("Exhaustivo");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("ExhaustivoPoda");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "Exhaustivo y Divide y Vencerás":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.Exhaustivo(puntos);
                    alg.DyV(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgE(), alg.getTiempoalgDV(), alg.getContE(), alg.getContDV()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgE());
                    tiempos2.add(alg.getTiempoalgDV());
                }
                generarDat(tallas, "Exhaustivo", tiempos);
                generarDat(tallas, "Divide y Vencerás", tiempos2);
                g2.setAlgo("Exhaustivo");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("Divide y Vencerás");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "Exhaustivo y DyV Mejorado":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.Exhaustivo(puntos);
                    alg.DyV_Mejorado(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgE(), alg.getTiempoalgDVM(), alg.getContE(), alg.getContDVM()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgE());
                    tiempos2.add(alg.getTiempoalgDVM());
                }
                generarDat(tallas, "Exhaustivo", tiempos);
                generarDat(tallas, "DyV Mejorado", tiempos2);
                g2.setAlgo("Exhaustivo");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("DyV Mejorado");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "ExhaustivoPoda y Exhaustivo":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.Exhaustivo(puntos);
                    alg.Exhaustivo_Poda(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgEP(), alg.getTiempoalgE(), alg.getContEP(), alg.getContE()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgE());
                    tiempos2.add(alg.getTiempoalgEP());
                }
                generarDat(tallas, "Exhaustivo", tiempos);
                generarDat(tallas, "ExhaustivoPoda", tiempos2);
                g2.setAlgo("Exhaustivo");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("ExhaustivoPoda");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "ExhaustivoPoda y ExhaustivoPoda":
                break;
            case "ExhaustivoPoda y Divide y Vencerás":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.Exhaustivo_Poda(puntos);
                    alg.DyV(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgEP(), alg.getTiempoalgDV(), alg.getContEP(), alg.getContDV()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgEP());
                    tiempos2.add(alg.getTiempoalgDV());
                }
                generarDat(tallas, "ExhaustivoPoda", tiempos);
                generarDat(tallas, "Divide y Vencerás", tiempos2);
                g2.setAlgo("ExhaustivoPoda");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("Divide y Vencerás Mejorado");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "ExhaustivoPoda y DyV Mejorado":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.DyV_Mejorado(puntos);
                    alg.Exhaustivo_Poda(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgEP(), alg.getTiempoalgDVM(), alg.getContEP(), alg.getContDVM()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgEP());
                    tiempos2.add(alg.getTiempoalgDVM());
                }
                generarDat(tallas, "ExhaustivoPoda", tiempos);
                generarDat(tallas, "DyV Mejorado", tiempos2);
                g2.setAlgo("ExhaustivoPoda");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("DyV Mejorado");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "Divide y Vencerás y Exhaustivo":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.Exhaustivo(puntos);
                    alg.DyV(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgDV(), alg.getTiempoalgE(), alg.getContDV(), alg.getContE()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgE());
                    tiempos2.add(alg.getTiempoalgDV());
                }
                generarDat(tallas, "Exhaustivo", tiempos);
                generarDat(tallas, "Divide y Vencerás", tiempos2);
                g2.setAlgo("Exhaustivo");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("Divide y Vencerás");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "Divide y Vencerás y ExhaustivoPoda":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.DyV(puntos);
                    alg.Exhaustivo_Poda(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgDV(), alg.getTiempoalgEP(), alg.getContDV(), alg.getContEP()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgEP());
                    tiempos2.add(alg.getTiempoalgDV());
                }
                generarDat(tallas, "ExhaustivoPoda", tiempos);
                generarDat(tallas, "Divide y Vencerás", tiempos2);
                g2.setAlgo("ExhaustivoPoda");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("Divide y Vencerás");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "Divide y Vencerás y Divide y Vencerás":
                break;
            case "Divide y Vencerás y DyV Mejorado":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.DyV(puntos);
                    alg.DyV_Mejorado(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgDV(), alg.getTiempoalgDVM(), alg.getContDV(), alg.getContDVM()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgDVM());
                    tiempos2.add(alg.getTiempoalgDV());
                }
                generarDat(tallas, "DyV Mejorado", tiempos);
                generarDat(tallas, "Divide y Vencerás", tiempos2);
                g2.setAlgo("Divide y Vencerás");
                g2.add(g2.paint(plot, tallas, tiempos2));
                g2.setAlgo("DyV Mejorado");
                g2.add(g2.paint(plot, tallas, tiempos));
                break;
            case "DyV Mejorado y Exhaustivo":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int)(double) tallas.get(i), false);
                    alg.Exhaustivo(puntos);
                    alg.DyV_Mejorado(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgDVM(), alg.getTiempoalgE(), alg.getContDVM(), alg.getContE()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgE());
                    tiempos2.add(alg.getTiempoalgDVM());
                }
                generarDat(tallas, "Exhaustivo", tiempos);
                generarDat(tallas, "DyV Mejorado", tiempos2);
                g2.setAlgo("Exhaustivo");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("DyV Mejorado");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "DyV Mejorado y ExhaustivoPoda":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int)(double) tallas.get(i), false);
                    alg.DyV_Mejorado(puntos);
                    alg.Exhaustivo_Poda(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgDVM(), alg.getTiempoalgEP(), alg.getContDVM(), alg.getContEP()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgEP());
                    tiempos2.add(alg.getTiempoalgDVM());
                }
                generarDat(tallas, "ExhaustivoPoda", tiempos);
                generarDat(tallas, "DyV Mejorado", tiempos2);
                g2.setAlgo("ExhaustivoPoda");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("DyV Mejorado");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "DyV Mejorado y Divide y Vencerás":
                model.setColumnIdentifiers(titulos2);
                jTable1.setModel(model);
                jLabel1.setText(text);
                for (int i = 0; i < tallas.size(); i++) {
                    puntos = alg.rellenarPuntos((int) (double) tallas.get(i), false);
                    alg.DyV_Mejorado(puntos);
                    alg.DyV(puntos);
                    Object[] row = {tallas.get(i), alg.getTiempoalgDVM(), alg.getTiempoalgDV(), alg.getContDVM(), alg.getContDV()};
                    model.addRow(row);
                    tiempos.add(alg.getTiempoalgDVM());
                    tiempos2.add(alg.getTiempoalgDV());
                }
                generarDat(tallas, "DyV Mejorado", tiempos);
                generarDat(tallas, "Divide y Vencerás", tiempos2);
                g2.setAlgo("DyV Mejorado");
                g2.add(g2.paint(plot, tallas, tiempos));
                g2.setAlgo("Divide y Vencerás");
                g2.add(g2.paint(plot, tallas, tiempos2));
                break;
            case "DyV Mejorado y DyV Mejorado":
                break;
            default:
                throw new AssertionError();
        }
        g2.setLocationRelativeTo(null);
        g2.setVisible(true);

    }

    private void generarDat(ArrayList tallas, String estrategia, ArrayList tiempo) {
        String fileName = estrategia + ".dat";

        JFrame j = new JFrame();

        try {
            FileWriter fileWriter = new FileWriter(fileName);
            PrintWriter printWriter = new PrintWriter(fileWriter);

            for (int i = 0; i < tallas.size(); i++) {
                if ("Exhaustivo".equals(estrategia)) {
                    printWriter.println(tallas.get(i) + " " + tiempo.get(i));
                } else if ("ExhaustivoPoda".equals(estrategia)) {
                    printWriter.println(tallas.get(i) + " " + tiempo.get(i));
                } else if ("DivideyVencerás".equals(estrategia)) {
                    printWriter.println(tallas.get(i) + " " + tiempo.get(i));
                } else {
                    printWriter.println(tallas.get(i) + " " + tiempo.get(i));

                }

            }
            printWriter.close();
            JOptionPane.showMessageDialog(j, ".dat creado", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private ArrayList Tallas(int tamanio) {
        ArrayList<Double> tallas = new ArrayList<>();

        for (double i = 500; i < tamanio + 1; i += 500) {
            tallas.add(i);
        }

        return tallas;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        volver = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        volver.setText("Volver");
        volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverActionPerformed(evt);
            }
        });

        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(volver))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 135, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(9, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(volver)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverActionPerformed
        // TODO add your handling code here:
        Vista v = new Vista();
        v.setLocationRelativeTo(null);
        v.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_volverActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton volver;
    // End of variables declaration//GEN-END:variables

}
