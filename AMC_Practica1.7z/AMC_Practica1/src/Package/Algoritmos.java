/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Package;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

/**
 *
 * @author rodri
 */
public class Algoritmos {

    private int contE;
    private int contEP;
    private int contDV = 0;
    private int contDVM = 0;
    private double tiempoalgE;
    private double tiempoalgEP;
    private double tiempoalgDV = 0;
    private double tiempoalgDVM = 0;

    public double getTiempoalgE() {
        return tiempoalgE;
    }

    public void setTiempoalgE(double tiempoalgE) {
        this.tiempoalgE = tiempoalgE;
    }

    public double getTiempoalgEP() {
        return tiempoalgEP;
    }

    public void setTiempoalgEP(double tiempoalgEP) {
        this.tiempoalgEP = tiempoalgEP;
    }

    public double getTiempoalgDV() {
        return tiempoalgDV;
    }

    public void setTiempoalgDV(double tiempoalgDV) {
        this.tiempoalgDV = tiempoalgDV;
    }

    public double getTiempoalgDVM() {
        return tiempoalgDVM;
    }

    public void setTiempoalgDVM(double tiempoalgDVM) {
        this.tiempoalgDVM = tiempoalgDVM;
    }

    public static ArrayList<Punto> rellenarPuntos(int n, boolean mismax) {
        ArrayList<Punto> puntos = new ArrayList<>();
        Random rand = new Random();

        if (mismax) { // PEOR CASO
            for (int i = 0; i < n; i++) {
                double aux1 = rand.nextInt(1000) + 7;
                double y = aux1 / ((double) i + 1 + i * 0.100);
                int num = rand.nextInt(3);
                y += ((i % 500) - num * (rand.nextInt(100)));
                double x = 1;
                puntos.add(new Punto(x, y, i + 1));
            }
        } else { // CASO MEDIO
            for (int i = 0; i < n; i++) {
                int num = rand.nextInt(4000) + 1;
                int den = rand.nextInt(11) + 7;
                double x = num / ((double) den + 0.37);
                double y = (rand.nextInt(4000) + 1) / ((double) (rand.nextInt(11) + 7) + 0.37);
                puntos.add(new Punto(x, y, i + 1));
            }
        }
        return puntos;
    }

    public static ArrayList quicksort(ArrayList<Punto> P, int izq, int der) {

        Punto pivote = P.get(izq);
        int i = izq;
        int j = der;
        Punto aux;

        while (i < j) {
            while (P.get(i).getX() <= pivote.getX() && i < j) {
                i++;
            }
            while (P.get(j).getX() > pivote.getX()) {
                j--;
            }
            if (i < j) {
                aux = P.get(i);
                P.set(i, P.get(j));
                P.set(j, aux);
            }
        }
        P.set(izq, P.get(j));
        P.set(j, pivote);

        if (izq < j - 1) {
            quicksort(P, izq, j - 1);
        }
        if (j + 1 < der) {
            quicksort(P, j + 1, der);
        }
        return P;
    }

    public ArrayList QuickSort(ArrayList<Punto> puntos) {
        quicksort(puntos, 0, puntos.size() - 1);
        return puntos;
    }

    private Recta Exhaustivo(ArrayList<Punto> puntos, int izq, int der) {
        double tiempoinicio = System.currentTimeMillis();
        contE = 0;
        double distanciaMinima = Double.POSITIVE_INFINITY;
        double distancia;
        Recta rectaMinima = null;
        for (int i = izq; i <= der; i++) {
            for (int j = i + 1; j <= der; j++) {
                contE++;
                distancia = distanciaEntrePuntos(puntos.get(i), puntos.get(j));
                if (distancia < distanciaMinima) {
                    distanciaMinima = distancia;
                    rectaMinima = new Recta(puntos.get(i), puntos.get(j));
                }
            }
        }
        double tiempofinal = System.currentTimeMillis();
        double tiempototal = (tiempofinal - tiempoinicio)/1000;
        setTiempoalgE(tiempototal);
        return rectaMinima;
    }

    public Recta Exhaustivo(ArrayList<Punto> puntos) {
        return Exhaustivo(puntos, 0, puntos.size() - 1);
    }

    public static double distanciaEntrePuntos(Punto p1, Punto p2) {
        return Math.sqrt(Math.pow(p2.getX() - p1.getX(), 2) + Math.pow(p2.getY() - p1.getY(), 2));
    }

    private Recta Exhaustivo_Poda(ArrayList<Punto> puntos, int izq, int der) {
        double tiempoinicio = System.currentTimeMillis();
        contEP = 0;
        double distanciaMinima = Double.MAX_VALUE;
        Recta rectaMinima = null;

        for (int i = izq; i <= der; i++) {
            for (int j = i + 1; j <= der; j++) {
                double diferenciaCoordenada = calcularDiferenciaCoordenadaY(puntos.get(i), puntos.get(j));
                if (diferenciaCoordenada < distanciaMinima) {
                    contEP++;
                    double distancia = distanciaEntrePuntos(puntos.get(i), puntos.get(j));
                    if (distancia < distanciaMinima) {
                        distanciaMinima = distancia;
                        rectaMinima = new Recta(puntos.get(i), puntos.get(j));
                    }
                }
            }
        }

        double tiempofinal = System.currentTimeMillis();
        double tiempototal = (tiempofinal - tiempoinicio)/1000;
        setTiempoalgEP(tiempototal);
        return rectaMinima;
    }

    private double calcularDiferenciaCoordenadaY(Punto punto1, Punto punto2) {
        return Math.abs(punto1.getY() - punto2.getY());
    }

    public Recta Exhaustivo_Poda(ArrayList<Punto> puntos) {
        return Exhaustivo_Poda(puntos, 0, puntos.size() - 1);
    }

    public Recta DyV(ArrayList<Punto> puntos) {
        QuickSort(puntos);
        Recta solucion = DyV(puntos, 0, puntos.size() - 1, 0);
        return solucion;
    }

    private Recta DyV(ArrayList<Punto> puntos, int izq, int der, int cont) {
        double tiempoinicio = System.currentTimeMillis();
        Recta solucion = null;
        if ((der - izq + 1) > 3) {
            int medio = (izq + der) / 2;
            Recta r1 = DyV(puntos, izq, medio, contDV);
            Recta r2 = DyV(puntos, medio + 1, der, contDV);
            contDV++;
            if (r1.distancia() < r2.distancia()) {
                solucion = r1;
            } else {
                solucion = r2;
            }
            double tiempofinal = System.currentTimeMillis();
            double tiempototal = (tiempofinal - tiempoinicio)/1000;
            setTiempoalgDV(tiempototal);
            return solucion;
        } else {
            solucion = ExhaustivoDV(puntos, izq, der);
            contDV++;
            double tiempofinal = System.currentTimeMillis();
            double tiempototal = (tiempofinal - tiempoinicio)/1000;
            setTiempoalgDV(tiempototal);
            return solucion;
        }

    }

    public Recta DyV_Mejorado(ArrayList<Punto> puntos) {
        QuickSort(puntos);
        Recta solucion = DyV_Mejorado(puntos, 0, puntos.size() - 1, 0);
        return solucion;
    }

    private Recta DyV_Mejorado(ArrayList<Punto> puntos, int izq, int der, int cont) {
        double tiempoinicio = System.currentTimeMillis();
        Recta dMin, DminIzq, DminDer, dAux;
        if ((der - izq + 1) > 3) {
            int medio = (der + izq) / 2;
            DminIzq = DyV_Mejorado(puntos, izq, medio, contDVM);
            DminDer = DyV_Mejorado(puntos, medio + 1, der, contDVM);
            if (DminIzq.distancia() < DminDer.distancia()) {
                dMin = DminIzq;
            } else {
                dMin = DminDer;
            }

            int a = medio;
            while (a >= izq && (puntos.get(medio + 1).getY() - puntos.get(a).getY()) < dMin.distancia()) {
                a--;
            }

            int b = medio + 1;
            while (b <= der && (puntos.get(b).getY() - puntos.get(medio).getY()) < dMin.distancia()) {
                b++;
            }

            dAux = ExhaustivoDV(puntos, a + 1, b - 1);
            if (dAux.distancia() < dMin.distancia()) {
                dMin = dAux;
            }
            double tiempofinal = System.currentTimeMillis();
            double tiempototal = (tiempofinal - tiempoinicio)/1000;
            setTiempoalgDVM(tiempototal);
            return dMin;
        } else {
            dMin = ExhaustivoDV(puntos, izq, der);
            contDVM++;
            double tiempofinal = System.currentTimeMillis();
            double tiempototal = (tiempofinal - tiempoinicio)/1000;
            setTiempoalgDVM(tiempototal);
            return dMin;
        }
    }

    private Recta ExhaustivoDV(ArrayList<Punto> puntos, int izq, int der) {
        double distanciaMinima = Double.MAX_VALUE;
        Recta rectaCorta = null;
        izq = 0;
        der = puntos.size() - 1;
        for (int i = izq; i <= der; i++) {
            for (int j = i + 1; j <= der; j++) {
                if (j != i) {

                    Punto actual = puntos.get(i);
                    Punto otro = puntos.get(j);

                    Recta posible = new Recta(actual, otro);

                    double dist = posible.distancia();

                    if (dist < distanciaMinima) {
                        distanciaMinima = dist;
                        rectaCorta = posible;
                    }
                }
            }
        }
        return rectaCorta;
    }

    public int getContE() {
        return contE;
    }

    public int getContEP() {
        return contEP;
    }

    public int getContDV() {
        return contDV;
    }

    public int getContDVM() {
        return contDVM;
    }
}
