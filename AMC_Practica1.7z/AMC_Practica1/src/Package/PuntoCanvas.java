/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Package;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author rodri
 */
public class PuntoCanvas extends Canvas {

    ArrayList<Punto> puntos;
    Recta solucion;

    public PuntoCanvas(int ancho, int alto, ArrayList<Punto> p, Recta solucion, double[][] graph) {

        super();
        this.setSize(ancho, alto);
        this.setBackground(Color.white);
        this.puntos = p;
        this.solucion = solucion;
    }

    @Override
    public void paint(Graphics g) {
        Font f1 = new Font("Arial", Font.BOLD, 12);
        g.setColor(Color.black);
        g.setFont(f1);
        for (int i = 0; i < puntos.size(); i++) {
            g.fillOval((int) puntos.get(i).getX(), (int) puntos.get(i).getY(), 5, 5);
            g.drawString(i + 1 + "", (int) puntos.get(i).getX(), (int) puntos.get(i).getY() - 5);
        }

        if (solucion != null) {
            g.setColor(Color.red);

            g.fillOval((int) solucion.getP1().getX(), (int) solucion.getP1().getY(), 5, 5);
            g.fillOval((int) solucion.getP2().getX(), (int) solucion.getP2().getY(), 5, 5);

            g.drawLine((int) solucion.getP1().getX() + 7, (int) solucion.getP1().getY(), (int) solucion.getP2().getX() + 7, (int) solucion.getP2().getY());
        }
    }
    
    @Override
    public void update(Graphics g) {
        paint(g);
    }
}